#'@title Check the frequency of a column.
#'@description This function will check the frequency of a column in the dataset. By default, the function gives a frequency table in decreasing order.
#'@param dataset The dataset to use.
#'@param column The name of the column to look at.
#'@param decreasing A logical value to determine the order of the frequency table. Default to TRUE.
#'@return dataset: the cleaned dataset. Usually have more rows than the original dataset.
#'@export
#'@examples
#'library(patents)
#'data('patent_data')
#'x1=clean_by(patent_data, "assigneeCity")
#'x1=check_frequency(x1, "assigneeCity")
check_frequency=function(dataset, column, decreasing=T){
  # input: dataset: the dataset to look at. Can be the original dataset or the cleaned dataset.
  #        column (chr): the column to look at.
  # output: a dataframe with two columns: the content and the frequency of the content
  # return the frequency table
  freq_table=as.data.frame(sort(table(dataset[[column]]),decreasing=decreasing))
  colnames(freq_table)=c(column,"frequency")
  return(freq_table)
}

